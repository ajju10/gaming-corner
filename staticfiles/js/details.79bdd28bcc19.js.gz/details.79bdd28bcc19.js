let joinButton = document.getElementById("joinButton");

joinButton.addEventListener('click', function () {
    alert('This feature is currently locked in Beta.');
});

// let profileButton = document.getElementById('profileButton');
//
// profileButton.addEventListener('click', function () {
//     alert('This feature is currently locked in Beta.');
// });